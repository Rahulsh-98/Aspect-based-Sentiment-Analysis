Place your project proposal in this directory.

A general template for the project proposal (in MS Word format) is located in this directory.

**When it comes to actual submission, you should create a PDF copy of your final proposal version and store it in this directory also.**

*Do not place any other files in this directory.*
